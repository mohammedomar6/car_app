class AppRoutes {

}