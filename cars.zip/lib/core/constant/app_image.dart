class AppImage {
  // splash
  static String logo='assets/image/splash/logo.png';
  static String splashBackground='assets/image/splash/background.png';
  // onboarding
static String o1='assets/image/onboarding/o1.png';
static String o2='assets/image/onboarding/o2.png';
static String o3='assets/image/onboarding/o3.png';
static String line='assets/image/onboarding/line.png';
// auth
  static String backgroundLogin='assets/image/auth/backgroundAuth.png';
  static String backgroundSignUp='assets/image/auth/create_account.png';
  // home
  static String ring='assets/image/main_screen/ring.png';

  static String sellCar ='assets/image/home/Container1.png';
  static String rentCar ='assets/image/home/Container2.png';
  static String finance ='assets/image/home/Container3.png';
  static String concierge ='assets/image/home/Container4.png';
  static String lamborghini ='assets/image/home/lamborghini.png';
  static String ferrari ='assets/image/home/ferrari.png';
  static String porsche ='assets/image/home/porsche.png';
  static String bmw ='assets/image/car/screen.png';
  static String  car ='assets/image/home/redCar.png';
  static String  energy ='assets/image/car/energy.png';
  static String  speed ='assets/image/car/speed.png';
  static String  timer ='assets/image/car/timer.png';
  static String  garage ='assets/image/profile/pro1.png';
  static String  list ='assets/image/profile/pro2.png';
  static String  history ='assets/image/profile/pro3.png';
  static String  security ='assets/image/profile/pro4.png';
  static String  support ='assets/image/profile/pro4.png';
  static String  logOut ='assets/image/profile/logOut.png';
  static String  arrowPro ='assets/image/profile/proIcon.png';
  static String  check ='assets/image/profile/check.png';
  static String  engine ='assets/image/car/engine.png';
  static String  fuelType ='assets/image/car/fuelType.png';
  static String  transmission ='assets/image/car/transmission.png';
  static String  driveType ='assets/image/car/driveType.png';
  static String  color ='assets/image/car/color.png';
  static String  profile ='assets/image/profile/profile.png';
  static String  profile1 ='assets/image/profile/profile1.png';
  static String  location ='assets/image/profile/location.png';
  static String  phone ="assets/image/profile/phone.png";
  static String  lock ="assets/image/profile/lock.png";
  static String  danger ="assets/image/profile/danger.png";
  static String  delete ="assets/image/profile/delete.png";
  static String  error ="assets/image/profile/error.png";




}
