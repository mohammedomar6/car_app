import 'package:car_app/core/theme/app_theme.dart';
import 'package:car_app/features/admin/data/data_sources/remote_data_source_admin.dart';
import 'package:car_app/features/admin/presentation/manager/approve_car/approve_car_bloc.dart';
import 'package:car_app/features/admin/presentation/manager/users/users_bloc.dart';
import 'package:car_app/features/admin/presentation/pages/admin_panel_home_screen.dart';
import 'package:car_app/features/admin/presentation/pages/all_user_screen.dart';
import 'package:car_app/features/auth/data/data_sources/remote_data_source_auth.dart';
import 'package:car_app/features/auth/presentation/manager/auth_bloc.dart';
import 'package:car_app/features/auth/presentation/manager/login_bloc/login_bloc.dart';
import 'package:car_app/features/auth/presentation/pages/login_screen.dart';
import 'package:car_app/features/auth/presentation/pages/sign_up_screen.dart';
import 'package:car_app/features/brand/data/data_sources/remote_data_source_brand.dart';
import 'package:car_app/features/brand/presentation/manager/brands_bloc.dart';
import 'package:car_app/features/cars/data/data_sources/remote_data_source_car.dart';
import 'package:car_app/features/cars/data/models/car_response_model.dart';
import 'package:car_app/features/cars/presentation/manager/car_bloc.dart';
import 'package:car_app/features/cars/presentation/pages/add_edit_car_screen.dart';
import 'package:car_app/features/brand/presentation/pages/brands_page.dart';
import 'package:car_app/features/cars/presentation/manager/pending_cars_bloc.dart';
import 'package:car_app/features/cars/presentation/pages/car_details.dart';
import 'package:car_app/features/cars/presentation/pages/pending_cars_screen.dart';
import 'package:car_app/features/favorites/data/data_sources/favorite_remote_data_source.dart';
import 'package:car_app/features/favorites/presentation/manager/favorite_bloc.dart';
import 'package:car_app/features/favorites/presentation/pages/favorite_screen.dart';
import 'package:car_app/features/cars/presentation/pages/cars_page.dart';
import 'package:car_app/features/orders/data/data_sources/order_remote_data_source.dart';
import 'package:car_app/features/orders/presentation/manager/order_bloc.dart';
import 'package:car_app/features/orders/presentation/pages/admin_orders_screen.dart';
import 'package:car_app/features/orders/presentation/pages/create_order_screen.dart';
import 'package:car_app/features/orders/presentation/pages/my_orders_screen.dart';
import 'package:car_app/features/orders/presentation/pages/order_details_screen.dart';
import 'package:car_app/features/orders/presentation/utils/order_details_arguments.dart';
import 'package:car_app/features/transactions/data/data_sources/transaction_remote_data_source.dart';
import 'package:car_app/features/transactions/presentation/manager/transaction_bloc.dart';
import 'package:car_app/features/transactions/presentation/pages/transaction_details_screen.dart';
import 'package:car_app/features/transactions/presentation/pages/transaction_form_screen.dart';
import 'package:car_app/features/transactions/presentation/pages/transactions_screen.dart';
import 'package:car_app/features/transactions/presentation/utils/transaction_route_arguments.dart';

import 'package:car_app/features/onbording/presentation/pages/onboarding_screen.dart';
import 'package:car_app/features/profile/data/data_sources/remote_data_source_profile.dart';
import 'package:car_app/features/profile/presentation/manager/profile_bloc.dart';
import 'package:car_app/features/profile/presentation/pages/account/account_screen.dart';
import 'package:car_app/features/profile/presentation/pages/garage/cars_in_garage.dart';

import 'package:car_app/features/splash/presentation/pages/splash_screen.dart';

import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'features/home/presentation/pages/home_screen.dart';
import 'features/main_screen/presentation/pages/main_screen.dart';
import 'features/profile/presentation/pages/account/change_password_screen.dart';
import 'features/profile/presentation/pages/account/edit_profile_screen.dart';
import 'features/profile/presentation/pages/profile_screen.dart';
import 'features/search/presentation/pages/search_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  runApp(
    EasyLocalization(
      startLocale: const Locale('en'),
      fallbackLocale: const Locale('en'),
      useOnlyLangCode: true,
      saveLocale: true,
      path: "assets/translation",
      supportedLocales: const [Locale('en'), Locale('ar')],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      minTextAdapt: true,
      useInheritedMediaQuery: true,

      designSize: Size(390, 884),
      builder: (context, child) {
        final fontFamily =
            context.locale.languageCode == 'ar' ? 'Alexandria' : 'Poppins';
        final lightTheme = AppTheme.lightTheme;
        final darkTheme = AppTheme.darkTheme;
        return MultiBlocProvider(
          providers: [
            BlocProvider(create: (context) => AuthBloc(RemoteDataSourceAuth())),
            BlocProvider(create: (context) => ApproveCarBloc(remoteDataSourceAdmin: RemoteDataSourceAdmin())),
            BlocProvider(
              create:
                  (context) => FavoriteBloc(
                    remoteDataSource: FavoriteRemoteDataSourceImpl(),
                  ),
            ),
            BlocProvider(
              create:
                  (context) => PendingCarsBloc(
                    remoteDataSourceAdmin: RemoteDataSourceAdmin(),
                  ),
            ),
            BlocProvider(
              create: (context) => LoginBloc(RemoteDataSourceAuth()),
            ),
            BlocProvider(
              create:
                  (context) =>
                      BrandsBloc(RemoteDataSourceBrand())
                        ..add(GetAllBrandsEvent()),
            ),
            BlocProvider(
              create:
                  (context) =>
                      CarBloc(RemoteDataSourceCar())..add(GetAllCars()),
            ),
            BlocProvider(
              create:
                  (context) =>
                      ProfileBloc(RemoteDataSourceProfile())
                        ..add(GetProfileEvent()),
            ),
            BlocProvider(
              create: (context) => UsersBloc(RemoteDataSourceAdmin()),
            ),
            BlocProvider(
              create: (context) => OrderBloc(OrderRemoteDataSource()),
            ),
            BlocProvider(
              create: (context) =>
                  TransactionBloc(TransactionRemoteDataSource()),
            ),
          ],
          child: MaterialApp(
            theme: lightTheme.copyWith(
              textTheme: lightTheme.textTheme.apply(fontFamily: fontFamily),
            ),
            darkTheme: darkTheme.copyWith(
              textTheme: darkTheme.textTheme.apply(fontFamily: fontFamily),
              primaryTextTheme:
                  darkTheme.primaryTextTheme.apply(fontFamily: fontFamily),
            ),
            themeMode: ThemeMode.dark,
            debugShowCheckedModeBanner: false,
            supportedLocales: context.supportedLocales,
            localizationsDelegates: context.localizationDelegates,
            locale: context.locale,

            routes: {
              '/': (context) => SplashScreen(),
              '/onboarding': (context) => OnboardingScreen(),
              '/login': (context) => LoginScreen(),
              '/sign_up': (context) => SignUpScreen(),
              '/main_screen': (context) => MainScreen(),
              '/home_screen': (context) => HomeScreen(),
              '/search_screen': (context) => SearchScreen(),
              '/add_car': (context) =>  AddEditCarScreen(),
              '/profile_screen': (context) => ProfileScreen(),
              '/favorite_screen': (context) => FavoriteScreen(),
              '/editProfile': (context) =>  EditProfileScreen(),
              '/changePassword': (context) =>
               ChangePasswordScreen(),
              '/cars_page': (context) {
                final brandId =
                ModalRoute.of(context)!.settings.arguments as int?;

                return CarsPage(
                  brandId: brandId,
                );
              },
              '/brands_page': (context) => BrandsPage(),
              '/car_details': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                final carId = arguments is CarResponseModel
                    ? arguments.carId
                    : arguments as int;
                return CarDetails(carId: carId);
              },
              '/cars_in_garage': (context) => CarsInGarage(),
              '/account_screen': (context) => AccountScreen(),
              '/admin_panel_screen': (context) => AdminPanelHomeScreen(),
              '/allUser': (context) => AllUserScreen(),
              '/pending_cars': (context) => PendingCarsScreen(),
              '/create_order': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                if (arguments is CreateOrderArguments) {
                  return CreateOrderScreen(
                    car: arguments.car,
                    initialType: arguments.initialType,
                  );
                }
                return CreateOrderScreen(
                  car: arguments as CarResponseModel,
                );
              },
              '/my_orders': (context) =>  MyOrdersScreen(),
              '/order_details': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                if (arguments is OrderDetailsArguments) {
                  return OrderDetailsScreen(
                    orderId: arguments.orderId,
                    isAdmin: arguments.isAdmin,
                    focusDocuments: arguments.focusDocuments,
                  );
                }
                return OrderDetailsScreen(orderId: arguments as int);
              },
              '/admin_orders': (context) =>  AdminOrdersScreen(),
              '/transactions': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                if (arguments is TransactionsScreenArguments) {
                  return TransactionsScreen(
                    isAdmin: arguments.isAdmin,
                    initialOrderId: arguments.initialOrderId,
                  );
                }
                return  TransactionsScreen();
              },
              '/transaction_form': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                if (arguments is TransactionFormArguments) {
                  return TransactionFormScreen(
                    order: arguments.order,
                    transaction: arguments.transaction,
                  );
                }
                return  TransactionFormScreen();
              },
              '/transaction_details': (context) {
                final arguments = ModalRoute.of(context)!.settings.arguments;
                if (arguments is TransactionDetailsArguments) {
                  return TransactionDetailsScreen(
                    transactionId: arguments.transactionId,
                    isAdmin: arguments.isAdmin,
                  );
                }
                return TransactionDetailsScreen(
                  transactionId: arguments as int,
                );
              },
            },
          ),
        );
      },
    );
  }
}
