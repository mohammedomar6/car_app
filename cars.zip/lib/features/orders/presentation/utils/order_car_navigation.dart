import 'package:flutter/material.dart';

class OrderCarNavigation {
  const OrderCarNavigation._();

  static void openCarDetails(
    BuildContext context,
    int carId,
  ) {
    Navigator.pushNamed(context, '/car_details', arguments: carId);
  }
}
